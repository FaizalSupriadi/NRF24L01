I made a simple library for the nrf24l01+ chip, with some more limited use. You are not able to use it to
transmit and receive data from multiple devices.
This library is created as a project for the Hogeschool Utrecht, HBO-ICT.

It is best used for simple projects that do not require extremely fast speed.

datasheet: https://infocenter.nordicsemi.com/pdf/nRF24L01P_PS_v1.0.pdf?cp=8_4_0_0

(c) Menno van der Jagt 2019

Distributed under the Boost Software License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at 
http://www.boost.org/LICENSE_1_0.txt)
