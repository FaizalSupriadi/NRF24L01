var searchData=
[
  ['nrf24',['NRF24',['../class_n_r_f24.html',1,'NRF24'],['../class_n_r_f24.html#aa46c8e32ec72d8b9fc1d267e8847064e',1,'NRF24::NRF24(hwlib::spi_bus &amp;bus, hwlib::pin_out &amp;ce, hwlib::pin_out &amp;csn)'],['../class_n_r_f24.html#a0c9003c0466931d1166dee232d195bdc',1,'NRF24::NRF24(hwlib::spi_bus &amp;bus, hwlib::pin_out &amp;ce, hwlib::pin_out &amp;csn, uint8_t payload_size, uint8_t addr_width)']]],
  ['nrf24_2ehpp',['NRF24.hpp',['../_n_r_f24_8hpp.html',1,'']]]
];
