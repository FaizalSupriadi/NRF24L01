var searchData=
[
  ['read',['read',['../class_n_r_f24.html#aeb8462ee674980d6e49f1f26c0f435e6',1,'NRF24']]],
  ['read_5fbyte',['read_byte',['../class_n_r_f24.html#a0d67356b65d9fe0b6ceb5ace3814e8e8',1,'NRF24']]],
  ['read_5fpayload',['read_payload',['../class_n_r_f24.html#a8e3cf35188c3a2824483b72677a34ff4',1,'NRF24']]],
  ['read_5fpipe',['read_pipe',['../class_n_r_f24.html#ae8ecc54e98fcec43a1c64459d9ee4b05',1,'NRF24']]],
  ['read_5fregister',['read_register',['../class_n_r_f24.html#abaddce712f45103e2ba5c7dd469d0f43',1,'NRF24::read_register(uint8_t reg)'],['../class_n_r_f24.html#ac7a15ebd2bf7391f3d7d158c23e80495',1,'NRF24::read_register(uint8_t reg, uint8_t *value, uint8_t len)']]],
  ['read_5fsetup',['read_setup',['../class_n_r_f24.html#a8b69683d1cec30029063daf11e5d5445',1,'NRF24']]],
  ['readallregisters',['readAllRegisters',['../class_n_r_f24.html#a48f2ac4512f78c5fb64e760957a2ecff',1,'NRF24']]]
];
