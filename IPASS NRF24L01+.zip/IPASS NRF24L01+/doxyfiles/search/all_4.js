var searchData=
[
  ['powerdown',['powerdown',['../class_n_r_f24.html#ac3b442917af9d2238e4958bb2315f93b',1,'NRF24']]],
  ['powerdown_5frx',['powerDown_rx',['../class_n_r_f24.html#a17c2a02cd736a759a9951e7c6ef5eb0e',1,'NRF24']]],
  ['powerup',['powerup',['../class_n_r_f24.html#a1894ffea55c12d3e907929928dbc5924',1,'NRF24']]],
  ['powerup_5frx',['powerUp_rx',['../class_n_r_f24.html#a2fa9d5da8cd59a1dfbb894574b0f2c91',1,'NRF24']]]
];
