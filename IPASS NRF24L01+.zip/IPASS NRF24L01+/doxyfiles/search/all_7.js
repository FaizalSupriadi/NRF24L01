var searchData=
[
  ['transfer',['transfer',['../class_n_r_f24.html#a056ef9105f5604a6c4895fee2e29f0a3',1,'NRF24']]]
];
