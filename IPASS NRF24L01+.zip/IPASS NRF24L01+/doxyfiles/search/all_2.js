var searchData=
[
  ['getaddresswidth',['getAddressWidth',['../class_n_r_f24.html#aa1909f80cb376dd78d85fe217afe9142',1,'NRF24']]],
  ['getchannel',['getChannel',['../class_n_r_f24.html#a20ecefdc481eeba0b877814bb46ce9cc',1,'NRF24']]],
  ['getdatarate',['getDataRate',['../class_n_r_f24.html#a9d16a3898e24d7a22dc31f5633811c01',1,'NRF24']]],
  ['getoutputpower',['getOutputPower',['../class_n_r_f24.html#a3efc16d104db8ca31a541ec0c6c647e2',1,'NRF24']]],
  ['getpayloadsize',['getPayloadSize',['../class_n_r_f24.html#a2dca6fc06936ce80eeb3b63923adabda',1,'NRF24']]],
  ['getretries',['getRetries',['../class_n_r_f24.html#a464586058e2fab1cff960956efd8d06d',1,'NRF24']]]
];
