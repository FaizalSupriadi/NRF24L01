var searchData=
[
  ['set_5fce',['set_ce',['../class_n_r_f24.html#aa7c093150a3a270e529996102bdb7526',1,'NRF24']]],
  ['set_5fcsn',['set_csn',['../class_n_r_f24.html#ab31e10bcd073e57b159af99f31ad0ff5',1,'NRF24']]],
  ['setaddresswidth',['setAddressWidth',['../class_n_r_f24.html#a338e197cc34dbe474a0c8ed29ad36731',1,'NRF24']]],
  ['setchannel',['setChannel',['../class_n_r_f24.html#a7c012875c0a1c5c348b15ec558e674e1',1,'NRF24']]],
  ['setdatarate',['setDataRate',['../class_n_r_f24.html#a46b98ca9136482de0debd2484a44fcb4',1,'NRF24']]],
  ['setoutputpower',['setOutputPower',['../class_n_r_f24.html#a1a54be21512169d841b6eaa4fb651ed6',1,'NRF24']]],
  ['setpayloadsize',['setPayloadSize',['../class_n_r_f24.html#a04ec0399f8a4203797eeed60a4fee2ba',1,'NRF24']]],
  ['setretries',['setRetries',['../class_n_r_f24.html#af73389cd37b795826f5e43f1651bdce3',1,'NRF24']]],
  ['start',['start',['../class_n_r_f24.html#ae8a5573ebd9b1a0173bf51c82a01edf9',1,'NRF24']]]
];
