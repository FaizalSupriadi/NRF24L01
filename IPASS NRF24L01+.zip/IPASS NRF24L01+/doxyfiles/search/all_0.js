var searchData=
[
  ['check_5ffifo',['check_fifo',['../class_n_r_f24.html#a62aad281d665a43fc2472c72a4b6db96',1,'NRF24']]],
  ['checkrxfifo',['checkRXfifo',['../class_n_r_f24.html#aaddc9707400f78004b9206c03dc0ad47',1,'NRF24']]]
];
