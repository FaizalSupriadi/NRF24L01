var searchData=
[
  ['flush_5frx',['flush_rx',['../class_n_r_f24.html#a4fa69480b42531e9f394a0a321073a7c',1,'NRF24']]],
  ['flush_5ftx',['flush_tx',['../class_n_r_f24.html#a3da75ff22da03dacbd2133b4275381b2',1,'NRF24']]]
];
